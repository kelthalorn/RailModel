import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-drag-drop',
  templateUrl: './drag-drop.component.html',
  styleUrls: ['./drag-drop.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DragDropComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
