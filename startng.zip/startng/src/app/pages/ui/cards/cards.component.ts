import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-cards',
  templateUrl: './cards.component.html',
  encapsulation: ViewEncapsulation.None
})
export class CardsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
